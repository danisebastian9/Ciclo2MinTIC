CREATE TABLE estudiantes (
    Nombres TEXT NOT NULL,
    Apellidos TEXT NOT NULL,
    FechaNacimiento TEXT NOT NULL,
    CorreoInstitucional TEXT NOT NULL PRIMARY KEY,
    CorreoPersonal TEXT NOT NULL,
    TelCel INTEGER NOT NULL,
    TelFijo INTEGER NOT NULL,
    Programa TEXT NOT NULL );

