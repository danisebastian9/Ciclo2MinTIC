//import Controlador.Controlador;

public class App {
    public static void main(String[] args) throws Exception {
        Controlador con = new Controlador();
        con.Control();
    }
}
